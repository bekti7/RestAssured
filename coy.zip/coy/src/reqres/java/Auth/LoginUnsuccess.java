package Auth;

import org.testng.annotations.Test;
import shared.BaseTest;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class LoginUnsuccess extends BaseTest {
    @Test
    public void Login2() {
        Map<String, Object> jsonAsMap = new HashMap<>();
        jsonAsMap.put("email", "eve.holt@reqres.in");

        System.out.println("Login Unsuccess");
        given().
                contentType("application/json").
                body(jsonAsMap).
                when().
                post("api/login")
                .then().statusCode(400).log().body();
    }
}
