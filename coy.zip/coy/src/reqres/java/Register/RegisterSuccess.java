package Register;

import org.testng.annotations.Test;
import shared.BaseTest;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class RegisterSuccess extends BaseTest {
    @Test
    public void register1() {
        Map<String, Object> jsonAsMap = new HashMap<>();
        jsonAsMap.put("email", "eve.holt@reqres.in");
        jsonAsMap.put("password", "pistol");
        System.out.println("Register Success");
        given().
                contentType("application/json").
                body(jsonAsMap).
                when().
                post("api/register")
                .then().statusCode(200).log().body();
    }
}
