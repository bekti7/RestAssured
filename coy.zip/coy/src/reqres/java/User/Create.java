package User;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import shared.BaseTest;

import static io.restassured.RestAssured.given;

public class Create extends BaseTest {
    @Test(dataProvider = "data-users")
    public void create1(String name, String job){
        RequestSpecification request = given();
        System.out.println("Create Users");
        JSONObject params = new JSONObject();
        params.put("name", name);
        params.put("job", job);

        request.body(params.toString());
        request.header("Content-Type", "application/json");
        Response response = request.post("/api/users");

        response.then().assertThat().statusCode(201);
        System.out.println(response.asString());
    }

    @DataProvider(name = "data-users")
    Object[][]DataUsers(){
        Object[][] users = new Object[][]{
                {"Jhoana", "Frontend"},
                {"Mimi", "Backend"},
                {"Shofie", "Designer"}
        };
        return users;
    }
}
