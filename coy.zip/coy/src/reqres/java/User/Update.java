package User;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.testng.annotations.Test;
import shared.BaseTest;

import static io.restassured.RestAssured.given;

public class Update extends BaseTest {
   @Test
   public void update1(){
       RequestSpecification request = given();
       System.out.println("Update User");
       JSONObject params = new JSONObject();
       params.put("name", "Jhoana");
       params.put("job", "Backend");

       request.body(params.toString());

       request.header("Content-Type", "application/json");
       Response response = request.post("/api/users");

       response.then().assertThat().statusCode(201);
       System.out.println(response.asString());
   }

}